let myLead = [];
let inputBtn = document.getElementById("input-btn");
const inputText = document.getElementById("input-el")
const ulEl = document.getElementById("ul-el");
inputBtn.addEventListener("click", function() {
    myLead.push(inputText.value);
    inputText.value = "";
    renderleads();
});


// function saveLead() {
//     console.log("logout");
// }

function renderleads() {
    let listItem = "";
    for (let i = 0; i < myLead.length; i++) {


        listItem += `
        <li>
        <a href='${myLead[i]}' target='_blank'> ${myLead[i]} </a>
        </li>`
            // const li = document.createElement("li");
            // li.textContent = myLead[i];
            // ulEl.append(li)
    }
    ulEl.innerHTML = listItem;
}